package com.iuni.myapplication


import android.os.Bundle
import android.content.Intent
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_case_manager_login.*
import kotlinx.android.synthetic.main.activity_login.*

class CaseManagerLogin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_case_manager_login)

        login_true_button_case_manager.setOnClickListener {
            val email_at_login_case_manager = email_edittext_case_manager_login_page.text.toString()
            val password_at_login_case_manager = password_edittext_case_manager_login_page.text.toString()

            if (email_at_login_case_manager.isEmpty() || password_at_login_case_manager.isEmpty()) return@setOnClickListener

            FirebaseAuth.getInstance().signInWithEmailAndPassword(email_at_login_case_manager, password_at_login_case_manager)
                .addOnCompleteListener {
                    if (!it.isSuccessful) return@addOnCompleteListener
                    Log.d("LoginActivity", "User has signed in.")

                    val intent = Intent(this, CaseManagerMenuMain::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK.or(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                }
        }

        create_account_case_manager_login.setOnClickListener {
            val intent = Intent(this, CaseManagerCreateAccount::class.java)
            startActivity(intent)
        }
    }
}