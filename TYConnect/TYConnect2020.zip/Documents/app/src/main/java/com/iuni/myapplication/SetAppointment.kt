package com.iuni.myapplication

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_set_appointment.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap


class SetAppointment: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_appointment)

        createCurrentWeekList()
    }

    private fun createCurrentWeekList() {
        var currentWeekList: ArrayList<Int> = arrayListOf()

        var c1 = Calendar.getInstance()
        var sdf = SimpleDateFormat("EEEE")
        var d = Date()
        var currentDay = sdf.format(d)

        c1.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        var day = c1.get(Calendar.DAY_OF_MONTH)
        currentWeekList.add(day)

        c1.set(Calendar.DAY_OF_WEEK, Calendar.TUESDAY)
        var day2 = c1.get(Calendar.DAY_OF_MONTH)
        currentWeekList.add(day2)

        c1.set(Calendar.DAY_OF_WEEK, Calendar.WEDNESDAY)
        var day3 = c1.get(Calendar.DAY_OF_MONTH)
        currentWeekList.add(day3)

        c1.set(Calendar.DAY_OF_WEEK, Calendar.THURSDAY)
        var day4 = c1.get(Calendar.DAY_OF_MONTH)
        currentWeekList.add(day4)

        c1.set(Calendar.DAY_OF_WEEK, Calendar.FRIDAY)
        var day5 = c1.get(Calendar.DAY_OF_MONTH)
        currentWeekList.add(day5)

        //Log.d("SetAppointment", currentWeekList.toString())
        createScheduleForWeek(currentWeekList, c1)
    }

    private fun createScheduleForWeek(currentWeekList: ArrayList<Int>, c1: Calendar) {
        //Import UI from XD, apply textviews as needed.
        var year = c1.get(Calendar.YEAR)
        var month = c1.get(Calendar.MONTH) + 1
        var curr_month_year = "$month/$year"

        month_year.text = curr_month_year

        mon_day.text = currentWeekList[0].toString()
        tue_day.text = currentWeekList[1].toString()
        wed_day.text = currentWeekList[2].toString()
        thu_day.text = currentWeekList[3].toString()
        fri_day.text = currentWeekList[4].toString()

        createSchedule()
    }

    private fun createSchedule() {
        var weekdayKeys = arrayListOf<String>(
            "MON", "TUE", "WED", "THU", "FRI"
        )

        var availabilityTimes = arrayListOf<String>()
        var scheduleHashMap = HashMap<String, ArrayList<String>>()

        for (string in weekdayKeys) {
            scheduleHashMap["$string"] = availabilityTimes
        }

        var shift = 8
        var i = 0

        while (i < 4) {
            availabilityTimes.add("$shift:00am")
            availabilityTimes.add("$shift:30am")
            shift++
            i++
        }

        shift = 1

        while (i < 9) {
            availabilityTimes.add("$shift:00pm")
            availabilityTimes.add("$shift:30pm")
            shift++
            i++
        }
        renderListView(scheduleHashMap)

    }

    private fun renderListView(scheduleHashMap: HashMap<String, ArrayList<String>>) {
        val listView = findViewById<ListView>(R.id.schedule_lv)

        listView.adapter = MyCustomAdapter(this)
    }

    private class MyCustomAdapter(context: Context): BaseAdapter() {

        private val mContext: Context

        init {
            mContext = context
        }
        //responsible for how many rows in my life
        override fun getCount(): Int {
            return 5
            TODO("Not yet implemented")
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getItem(position: Int): Any {
            return "TEST STRING"
        }

        //responsible for rendering each row
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
//            val textView = TextView(mContext)
//            textView.text = "HERE IS THE THINg"
//            return textView
            val layoutInflater = LayoutInflater.from(mContext)
            val rowMain = layoutInflater.inflate(R.layout.row_setappointment_timeslot, viewGroup, false)
            return rowMain

        }
    }
}