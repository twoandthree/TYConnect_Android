package com.iuni.myapplication

import android.graphics.Color
import android.os.Bundle
import android.service.autofill.OnClickAction
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_set_appointment.*
import kotlinx.android.synthetic.main.time_row.view.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap


class SetAppointment: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_appointment)

        createCurrentWeekList()
    }

    private fun createCurrentWeekList() {
        var currentWeekList: ArrayList<Int> = arrayListOf()

        var c1 = Calendar.getInstance()
        var sdf = SimpleDateFormat("EEEE")
        var d = Date()
        var currentDay = sdf.format(d)

        c1.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        var day = c1.get(Calendar.DAY_OF_MONTH)
        currentWeekList.add(day)

        c1.set(Calendar.DAY_OF_WEEK, Calendar.TUESDAY)
        var day2 = c1.get(Calendar.DAY_OF_MONTH)
        currentWeekList.add(day2)

        c1.set(Calendar.DAY_OF_WEEK, Calendar.WEDNESDAY)
        var day3 = c1.get(Calendar.DAY_OF_MONTH)
        currentWeekList.add(day3)

        c1.set(Calendar.DAY_OF_WEEK, Calendar.THURSDAY)
        var day4 = c1.get(Calendar.DAY_OF_MONTH)
        currentWeekList.add(day4)

        c1.set(Calendar.DAY_OF_WEEK, Calendar.FRIDAY)
        var day5 = c1.get(Calendar.DAY_OF_MONTH)
        currentWeekList.add(day5)

        //Log.d("SetAppointment", currentWeekList.toString())
        createScheduleForWeek(currentWeekList, c1)
    }

    private fun createScheduleForWeek(currentWeekList: ArrayList<Int>, c1: Calendar) {
        //Import UI from XD, apply textviews as needed.
        var year = c1.get(Calendar.YEAR)
        var month = c1.get(Calendar.MONTH) + 1
        var curr_month_year = "$month/$year"

        month_year.text = curr_month_year

        mon_day.text = currentWeekList[0].toString()
        tue_day.text = currentWeekList[1].toString()
        wed_day.text = currentWeekList[2].toString()
        thu_day.text = currentWeekList[3].toString()
        fri_day.text = currentWeekList[4].toString()

        createSchedule()
    }

    private fun createSchedule() {
        var weekdayKeys = arrayListOf<String>(
            "Mon", "Tue", "Wed", "Thu", "Fri"
        )

        var availabilityTimes = ArrayList<Pair<String, String>>()
        var scheduleHashMap = HashMap<String, ArrayList<Pair<String, String>>>()

        for (string in weekdayKeys) {
            scheduleHashMap["$string"] = availabilityTimes
        }

        var shift = 8
        var i = 0

        while (i < 4) {
            var pair_00 = Pair("$shift:00am", "Open")
            var pair_30 = Pair("$shift:30am", "Open")
            availabilityTimes.add(pair_00)
            availabilityTimes.add(pair_30)
            shift++
            i++
        }

        shift = 1

        while (i < 8) {
            var pair_00 = Pair("$shift:00pm", "Open")
            var pair_30 = Pair("$shift:30pm", "Open")
            availabilityTimes.add(pair_00)
            availabilityTimes.add(pair_30)
            shift++
            i++
        }

//        Log.d("SetAppointment", availabilityTimes.toString())
        setSchedule(scheduleHashMap)
//        uploadSchedule(scheduleHashMap)
    }

    private fun setSchedule(scheduleHashMap: HashMap<String, ArrayList<Pair<String, String>>>) {
        var c1 = Calendar.getInstance()
        var sdf = SimpleDateFormat("EEEE")
        var d = Date()
        var currentDay = sdf.format(d)

//        val uid = FirebaseAuth.getInstance().currentUser?.uid
//        val ref = FirebaseDatabase.getInstance().reference

        var weekDayArray = arrayListOf<TextView>(Monday, Tuesday, Wednesday, Thursday, Friday)
        //Log.d("SetAppointment", weekDayArray.toString())
        val color = Color.parseColor("#2BBF58")
        val colorTransparent = Color.parseColor("#00000000")
        weekDayArray[0].setBackgroundColor(color)

        var currentDaySelected = weekDayArray[0]

        var abbreviationDay = currentDaySelected.text.substring(0, 3)


        //Send these two to getView()
        var scheduleForSelectedDay = scheduleHashMap[abbreviationDay]
        var timeSelectedOpenClose = scheduleForSelectedDay?.get(0)

        var leftRight = 0
        var upDown = 0

        var openTimes = mutableListOf<String>()
        var selectedTimesHashMap = HashMap<String, MutableList<String>>()
//        selectedTimesHashMap[abbreviationDay] = openTimes

//        Log.d("SetAppointment", selectedTimesHashMap.toString())
//        Log.d(
//            "SetAppointment",
//            abbreviationDay
//        )

//        renderListView(
//            scheduleForSelectedDay,
//            timeSelectedOpenClose,
//            upDown,
//            up_button,
//            down_button,
//            abbreviationDay,
//            selectedTimesHashMap
//        )
        recyclerview_time_slots.layoutManager = LinearLayoutManager(this)
        recyclerview_time_slots.adapter = MyAdapter(scheduleForSelectedDay, selectedTimesHashMap)

        right_button.setOnClickListener {
            //Implement ClickListeners for up and down buttons, and
            //set schedule by setting whether the time slow is open or not.
            //lastly upload schedule to Database
            leftRight++

            if (leftRight == 5) {
                leftRight = 0
            }

            currentDaySelected.setBackgroundColor(colorTransparent)
            currentDaySelected = weekDayArray[leftRight]
            currentDaySelected.setBackgroundColor(color)

            currentDaySelected = weekDayArray[leftRight]
            //Log.d("SetAppointment", currentDaySelected.toString())
            abbreviationDay = currentDaySelected.text.substring(0, 3)
            //Log.d("SetAppointment", abbreviationDay)
            //selectedTimesHashMap[abbreviationDay] = openTimes
            //Log.d("SetAppointment", openTimes.toString())
            scheduleForSelectedDay = scheduleHashMap[abbreviationDay]
            //Log.d("SetAppointment", scheduleForSelectedDay.toString())
            recyclerview_time_slots.layoutManager = LinearLayoutManager(this)
            recyclerview_time_slots.adapter = MyAdapter(
                scheduleForSelectedDay,
                selectedTimesHashMap
            )

//            renderListView(
//                scheduleForSelectedDay,
//                timeSelectedOpenClose,
//                upDown,
//                up_button,
//                down_button,
//                abbreviationDay,
//                selectedTimesHashMap
//            )
        }

        left_button.setOnClickListener {
            leftRight--

            if (leftRight < 0) {
                leftRight = 4
            }
            currentDaySelected.setBackgroundColor(colorTransparent)
            currentDaySelected = weekDayArray[leftRight]
            currentDaySelected.setBackgroundColor(color)

            currentDaySelected = weekDayArray[leftRight]
            //Log.d("SetAppointment", currentDaySelected.toString())
            abbreviationDay = currentDaySelected.text.substring(0, 3)
            //Log.d("SetAppointment", abbreviationDay)
            //selectedTimesHashMap[abbreviationDay] = openTimes
            //Log.d("SetAppointment", openTimes.toString())
            scheduleForSelectedDay = scheduleHashMap[abbreviationDay]
            //Log.d("SetAppointment", scheduleForSelectedDay.toString())


//            var currentDay = currentDaySelected

//            renderListView(
//                scheduleForSelectedDay,
//                timeSelectedOpenClose,
//                upDown,
//                up_button,
//                down_button,
//                abbreviationDay,
//                selectedTimesHashMap
//            )

            recyclerview_time_slots.layoutManager = LinearLayoutManager(this)
            recyclerview_time_slots.adapter = MyAdapter(
                scheduleForSelectedDay,
                selectedTimesHashMap
            )
        }
    }

    class ModelForTopics() {
        var isSelected: Boolean = false
    }


    class MyAdapter(
        val scheduleForSelectedDay: java.util.ArrayList<Pair<String, String>>?,
        val selectedTimesHashMap: HashMap<String, MutableList<String>>,
        var isSelected: Boolean = false,
        private var currentRow: Int = 0

    ) :RecyclerView.Adapter<CustomViewHolder>() {

        override fun getItemCount(): Int {
            return 16
        }

        // Create new views (invoked by the layout manager)
        override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
        ): CustomViewHolder {
            // create a new view
            val textView = LayoutInflater.from(parent?.context)
            val cellRow = textView.inflate(R.layout.time_row, parent, false)
            return CustomViewHolder(cellRow)
        }

        // Replace the contents of a view (invoked by the layout manager)
        override fun onBindViewHolder(holder: CustomViewHolder, position: Int) {
            var arrayFirst = arrayListOf<String>()

            if (scheduleForSelectedDay != null) {
                for (item in scheduleForSelectedDay) {
                    arrayFirst.add(item.first)
                }
            }

            holder.view.available_time.text = arrayFirst[position]

            holder.view.available_time.setOnClickListener {
                if (holder.view.available_time.isSelected) {
                    currentRow = position
                }

                if (currentRow == position) {
                    notifyItemChanged(currentRow)
                    currentRow = RecyclerView.NO_POSITION
                } else {
                    currentRow = position
                    notifyItemChanged(currentRow)
                }
            }

            if (currentRow == position) {
                holder.view.available_time.setTextColor(Color.parseColor("#21C754"))
                holder.view.available_time.isSelected = true
            } else {
                holder.view.available_time.setTextColor(Color.parseColor("#726C6C"))
                holder.view.available_time.isSelected = false
            }
        }
    }


    class CustomViewHolder(val view: View): RecyclerView.ViewHolder(view) {

    }


























//    private fun renderListView(
//        //Here the function takes in a variety of parameters.
//        //selectedDayToSetSchedule is perhaps the most imporant.
//        //selectedDayToSetSchedule holds all the times, and whether the time is available or not:
//        //{Mon : [(8:00am, open), (8:30am, open), (9:00am, open)...
//        //{Tue : [(8:00am, open), (8:30am, open), (9:00am, open)...
//        //{Wed : [(8:00am, open), (8:30am, open), (9:00am, open)...
//        selectedDayToSetSchedule: java.util.ArrayList<Pair<String, String>>?,
//        timeSelectedOpenClose: Pair<String, String>?,
//        upDown: Int,
//        up_button: ImageView,
//        down_button: ImageView,
//        abbreviationDay: String,
//        selectedTimesHashMap: HashMap<String, MutableList<String>>
//    ) {
//        //Here the ListView is linked to the adapter.
//        //I am still learning what this means exactly.
//        //Although I know this is how I like the xml file to the listView, perhaps?
//        val listView = findViewById<ListView>(R.id.schedule_lv)
//        listView.adapter = MyCustomAdapter(
//            this, selectedDayToSetSchedule, upDown,
//            up_button, down_button, abbreviationDay, selectedTimesHashMap,
//            listView
//        )
//    }
//
//    //I took this piece from Brian Voong's tutorial on Youtube, on how to utilize the ListView.
//    //Since I learned it from a tutorial, I didn't get to learn about ListView really.
//    //Here, all the arguments are passed in so that I may use them in the function down below
//    //which is getView.
//    private class MyCustomAdapter(
//        context: Context,
//        selectedDayToSetSchedule: java.util.ArrayList<Pair<String, String>>?,
//        upDown: Int,
//        up_button: ImageView,
//        down_button: ImageView,
//        abbreviationDay: String,
//        selectedTimesHashMap: HashMap<String, MutableList<String>>,
//        listView: ListView,
//    ): BaseAdapter() {
//
//        private val mContext: Context
//        private val selectedSchedule = selectedDayToSetSchedule
//        private val upDownCounter = upDown
//        private val upButton = up_button
//        private val downBoolean = down_button
//        private val abbrDay = abbreviationDay
//        private val selectedTimeHashMap = selectedTimesHashMap
//        private val listView = listView
//
//        init {
//            selectedSchedule
//            upDownCounter
//            upButton
//            downBoolean
//            abbrDay
//            selectedTimeHashMap
//            listView
//            mContext = context
//        }
//
//        override fun getCount(): Int {
//            //Count of how many elements are in the values of selectedTimeSchedule
//            //{Mon : [(8:00am, open), (8:30am, open), (9:00am, open) 16 more elements
//            //{Tue : [(8:00am, open), (8:30am, open), (9:00am, open) 16 more elements
//            //{Wed : [(8:00am, open), (8:30am, open), (9:00am, open) 16 more elements
//            return 16
//        }
//
//        override fun getItemId(position: Int): Long {
//            return position.toLong()
//        }
//
//        override fun getItem(position: Int): Any {
//            return "TEST STRING"
//        }
//
//        override fun getView(position: Int, convertView: View?, viewGroup: ViewGroup?): View? {
//            //I'm not entirely sure how this works, however I know this is how I access the
//            //xml files holding all the elements, TextViews, ListView.
//            //rowMain holds the xml file containing the TextView which is generated for every time
//            //slot within:
//            ////{Mon : [(8:00am, open), (8:30am, open), (9:00am, open) 16 more elements
//            //all the times are the rendered unto the ListView.
//            val layoutInflater = LayoutInflater.from(mContext)
//            val rowMain = layoutInflater.inflate(R.layout.recycler_view_time_slots, viewGroup, false)
//            val weekdays = layoutInflater.inflate(R.layout.activity_set_appointment, viewGroup, false)
//            val timeSlotView = rowMain.findViewById<TextView>(R.id.time_textview)
//
//            var arrayFirst = arrayListOf<String>()
//
//            //Here all the times are added to an array
//            //[8:00am, 8:30am...]
//            if (selectedSchedule != null) {
//                for (item in selectedSchedule) {
//                    arrayFirst.add(item.first)
//                }
//            }
//
//            var c1 = Calendar.getInstance()
//            var sdf = SimpleDateFormat("EEEE")
//            var d = Date()
//            var currentDay = sdf.format(d)
//
//            //Here, each TextView is set to the times within arrayFirst
//            //Where all the times where stored.
//            timeSlotView.text = arrayFirst[position]
//
//            //Open time hold the time that was selected from the row
//            //Open times is an array of all the selected times that will be uploaded to Firebase
//            var openTime = timeSlotView.text.toString()
//            var openTimes = mutableListOf<String>()
//
//            if (!selectedTimeHashMap.keys.contains(abbrDay)) {
//                selectedTimeHashMap[abbrDay] = openTimes
//            }
//
//            rowMain.setOnClickListener {
//                //item has been deselected, thus returning to Grey.
//                //When a user selected a time from the ListView,
//                //we return that time, and add it to the array OpenTimes
//
//                val savedState = listView.onSaveInstanceState()
//                if (selectedTimeHashMap[abbrDay]?.contains(openTime)!!) {
//                    //In this if statement, if the user selects a time that's already
//                    //in openTimes, then that means they've deselected the time,
//                    //and no longer wish to include it.
//                    //Therefore the text much return back to Gray.
//                    selectedTimeHashMap[abbrDay]?.remove(openTime)
//                    timeSlotView.setTextColor(Color.parseColor("#595656"))
//                    listView.onRestoreInstanceState(savedState)
//
//                } else {
//                    //item has been selected to be open, thus the text is set to Green.
//                    //Here the user selects the time, and the text turns Green.
//                    //The text must retain it's Green color until the user deselects the time.
//                    Log.d("SetAppointment", listView.getChildAt(position).toString())
//                    selectedTimeHashMap[abbrDay]?.add(openTime)
//                    timeSlotView.setTextColor(Color.parseColor("#2FB557"))
//                    notifyDataSetChanged()
//                }
//            }
//            return rowMain
//        }
//    }
//
//    private fun uploadSchedule(scheduleHashMap: HashMap<String, ArrayList<Pair<String, String>>>) {
//        val updateUser = FirebaseAuth.getInstance().currentUser?.uid
//        val refForUpdate = FirebaseDatabase.getInstance().reference
//
//        for ((key, value) in scheduleHashMap) {
//            if (updateUser != null) {
//                refForUpdate.child("/case_managers").child(updateUser).child(key)
//                    .setValue(value)
//                }
//            }
//        }
}
